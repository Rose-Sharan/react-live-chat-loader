👋🏻 Hi there! 

This template will help you describe the work you’ve done, so one of the project maintainers can review and potentially accept it promptly. Please fill relevant sections below and feel free to delete what does not apply to your work (including this comment).

Thank you for helping us improve React Live Chat Loader! ⚡️

***

## What does this PR introduce?
In a few bullet points, please describe the changes this Pull Request makes. e.g.:

- adds a new chat provider
- fixes #
- updates `README.md` with a better description for contributions

## Related issues
Are there any related [issues or feature requests](https://github.com/calibreapp/react-live-chat-loader/issues) this work will resolve? Please mention them here. e.g.:

- closes #

Learn more about linking Pull Requests to issues [here](https://docs.github.com/en/github/managing-your-work-on-github/linking-a-pull-request-to-an-issue).

## Screenshots
If this work introduces any visual changes, add screenshots to portray them.
