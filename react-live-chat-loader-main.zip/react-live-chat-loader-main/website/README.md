# React Live Chat Loader Example App

An example [Next.js](https://nextjs.org) application using
[react-live-chat-loader](https://github.com/calibreapp/react-live-chat-loader)
